# App Lista de Tareas con Javascript

![Thumb](https://raw.githubusercontent.com/falconmasters/lista-tareas/master/img/Como%20hacer%20una%20App%20Lista%20de%20Tareas%20con%20Javascript.jpg)

Demo: http://codepen.io/falconmasters/pen/RWrYaP

### Tutorial: [http://www.falconmasters.com/javascript/app-lista-tareas-javascript/](http://www.falconmasters.com/javascript/app-lista-tareas-javascript/)

Por [Carlos Arturo](http://www.twitter.com/falconmasters)
## [FalconMasters, Blog de Diseño y Desarrollo Web](http://www.falconmasters.com)

---